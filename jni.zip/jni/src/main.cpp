#include <iostream>
#include <string>
#include <vector>
#include <cstdio>
#include <cstdlib>
//本刷入器根据香菜
struct DriverItem {
    int id;
    std::string name;
    const std::string &hex;
};
extern const std::vector<DriverItem> g_driverList;
extern std::string getKernelVersion();
extern bool isModuleLoaded(const std::string &modName);
extern std::string autoSelectKoHex(const std::string &ver);
extern int doFlashKo(const std::string &koHex);

// 颜色宏
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define CYAN    "\033[36m"
#define WHITE   "\033[37m"
#define RESET   "\033[0m"

// 长分割线
void printSep()
{
    std::cout << CYAN
              << "──────────────────────────────────────────────────────────"
              << RESET << std::endl;
}

// 大Logo标题
void showLogo()
{
    std::cout << std::endl;
    std::cout << GREEN;
    printf("██   ██  ██████   ██████ \n");
printf(" ██ ██   ██   ██  ██   ██ \n");
printf("  ███    ██   ██  ██   ██ \n");
printf(" ██ ██   ██   ██  ██   ██ \n");
printf("██   ██  ██████   ██████  \n");
    std::cout << RESET;
}

// 程序信息横幅
void showInfoBanner(const std::string &kernelVer)
{
    printSep();
    std::cout << WHITE << "  📦 驱动刷入工具 | 内核版本: " << YELLOW << kernelVer << RESET << std::endl;
    printSep();
}

// 主功能菜单
void showMenu()
{
    std::cout << std::endl;
    std::cout << BLUE << "【 功能菜单 】" << RESET << std::endl;
    std::cout << GREEN << "  [1] 自动刷入 → 根据内核版本自动匹配驱动" << RESET << std::endl;
    std::cout << GREEN << "  [2] 手动刷入 → 手动选择指定驱动版本" << RESET << std::endl;
    std::cout << RED  << "  [0] 退出程序" << RESET << std::endl;
    printSep();
}

// 按回车继续，暂停看输出
void pauseEnter()
{
    std::cout << YELLOW << "\n按回车键退出..." << RESET;
    std::cin.ignore();
    std::cin.get();
}

int main()
{
    showLogo();
    std::string kerVer = getKernelVersion();
    showInfoBanner(kerVer);

    int mode = -1;
    showMenu();
    std::cout << YELLOW << "请输入选择: " << RESET;
    std::cin >> mode;

    std::string koHex;

    if(mode == 0)
    {
        std::cout << WHITE << "\n👋 程序退出" << RESET << std::endl;
        return 0;
    }
    else if(mode == 1)
    {
        std::cout << std::endl;
        std::cout << CYAN << "[*] 正在自动匹配内核驱动..." << RESET << std::endl;
        koHex = autoSelectKoHex(kerVer);
        if(koHex.empty())
        {
            std::cout << RED << "\n[!] 自动匹配失败，没有对应版本驱动，请使用手动模式" << RESET << std::endl;
            pauseEnter();
            return 1;
        }
    }
    else if(mode == 2)
    {
        printSep();
        std::cout << BLUE << "📋 全部可用驱动列表：" << RESET << std::endl;
        for(auto &item : g_driverList)
        {
            printf(GREEN "    [%2d] %s\n" RESET, item.id, item.name.c_str());
        }
        printSep();
        std::cout << YELLOW << "请输入要刷入驱动的编号: " << RESET;
        int selId;
        std::cin >> selId;
        bool found = false;
        for(auto &item : g_driverList)
        {
            if(item.id == selId)
            {
                std::cout << GREEN << "\n[+] 已选定驱动: " << item.name << RESET << std::endl;
                koHex = item.hex;
                found = true;
                break;
            }
        }
        if(!found)
        {
            std::cout << RED << "\n[!] 错误：无效驱动编号！" << RESET << std::endl;
            pauseEnter();
            return 1;
        }
    }
    else
    {
        std::cout << RED << "\n[!] 无效输入，请重新运行程序！" << RESET << std::endl;
        pauseEnter();
        return 1;
    }

    printSep();
    std::cout << CYAN << "[*] 开始执行insmod刷入模块..." << RESET << std::endl;
    int flashRet = doFlashKo(koHex);
    printSep();

    if(flashRet == 0)
    {
        std::cout << GREEN << "✅ SUCCESS：insmod调用成功！" << RESET << std::endl;
        std::cout << WHITE << "💡 提示：请关闭本工具，重新打开你的顺风耳内核" << RESET << std::endl;
    }
    else
    {
        std::cout << RED << "❌ FAILED：刷入执行失败！" << RESET << std::endl;
        std::cout << YELLOW << "🔎排查方向：" << RESET << std::endl;
        std::cout << YELLOW << "   · 是否拥有完整ROOT权限\n" << RESET;
        
        std::cout << YELLOW << "   · KO模块与当前内核版本是否严格匹配\n" << RESET;
    }
    printSep();
    pauseEnter();
    return 0;
}
