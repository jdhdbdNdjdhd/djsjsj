LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_MODULE    := 独家驱动刷入器.sh
LOCAL_SRC_FILES := src/刷入.cpp src/main.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/src

LOCAL_CFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -fpermissive -fexceptions -std=c++17
LOCAL_CPPFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -std=c++17 -fpermissive -fexceptions

include $(BUILD_EXECUTABLE)
