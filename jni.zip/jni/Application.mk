APP_ABI := arm64-v8a
APP_PLATFORM := android-28
APP_STL := c++_static
APP_CPPFLAGS += -fexceptions
APP_CPPFLAGS += -fexceptions

APP_CPPFLAGS += -fexceptions
APP_CPPFLAGS += -fexceptions
