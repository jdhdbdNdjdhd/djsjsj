#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <dirent.h>
#include <sys/stat.h>
#include <random>
#include <ctime>
#include <cstring>
#include <vector>

// 直接包含驱动头
#include "驱动/A12-5.10.h"
#include "驱动/A13-5.10.h"
#include "驱动/A13-5.15.h"
#include "驱动/A14-5.15.h"
#include "驱动/A14-6.1.h"
#include "驱动/A15-6.6.h"
#include "驱动/A16-6.12.38.h"
#include "驱动/A16-6.12.58.h"
#include "驱动/A16-6.12.69.h"

struct DriverItem {
    int id;
    std::string name;
    const std::string &hex;
};

// 全局驱动列表，ui_main用extern引用
extern const std::vector<DriverItem> g_driverList = {
    {1, "A12‑5.10",     A12_5_10},
    {2, "A13‑5.10",     A13_5_10},
    {3, "A13‑5.15",     A13_5_15},
    {4, "A14‑5.15",     A14_5_15},
    {5, "A14‑6.1",      A14_6_1},
    {6, "A15‑6.6",      A15_6_6},
    {7, "A16‑6.12.38",  A16_6_12_38},
    {8, "A16‑6.12.58",  A16_6_12_58},
    {9, "A16‑6.12.69",  A16_6_12_69},
};

static bool hexStringToFile(const std::string &hexData, const std::string &outPath)
{
    std::ofstream out(outPath, std::ios::binary);
    if (!out.is_open())
    {
        fprintf(stderr, "[-] 无法打开输出文件 %s\n", outPath.c_str());
        return false;
    }
    for (size_t i = 0; i + 1 < hexData.size(); i += 2)
    {
        std::string byteStr = hexData.substr(i, 2);
        unsigned char byte = static_cast<unsigned char>(std::stoi(byteStr, nullptr, 16));
        out.put(byte);
    }
    out.close();
    return true;
}

static std::string generateRandomStr(size_t len)
{
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    std::default_random_engine eng(static_cast<unsigned int>(time(nullptr)));
    std::uniform_int_distribution<size_t> dist(0, sizeof(charset)-2);
    std::string res;
    res.reserve(len);
    for(size_t i=0;i<len;i++)
    {
        res += charset[dist(eng)];
    }
    return res;
}

static std::string getRandomDataDir()
{
    const char base[] = "/data/user/0";
    DIR* dir = opendir(base);
    if(!dir) return "/data/local/tmp";
    std::vector<std::string> dirs;
    dirent* ent;
    while((ent = readdir(dir)) != nullptr)
    {
        if(strcmp(ent->d_name,".")==0 || strcmp(ent->d_name,"..")==0) continue;
        std::string full = std::string(base) + "/" + ent->d_name;
        struct stat st{};
        if(stat(full.c_str(),&st)==0 && S_ISDIR(st.st_mode))
        {
            dirs.push_back(full);
        }
    }
    closedir(dir);
    if(dirs.empty()) return "/data/local/tmp";
    std::mt19937 rng(time(nullptr));
    std::uniform_int_distribution<> dis(0, (int)dirs.size()-1);
    return dirs[dis(rng)];
}

std::string getKernelVersion()
{
    FILE* fp = popen("uname -r","r");
    if(!fp) return "";
    char buf[256]={0};
    fgets(buf,sizeof(buf),fp);
    pclose(fp);
    buf[strcspn(buf,"\n\r")]=0;
    return std::string(buf);
}

bool isModuleLoaded(const std::string &modName)
{
    FILE* fp = fopen("/proc/modules","r");
    if(!fp) return false;
    char line[512];
    bool found = false;
    while(fgets(line,sizeof(line),fp))
    {
        if(strstr(line, modName.c_str()))
        {
            found = true;
            break;
        }
    }
    fclose(fp);
    return found;
}

std::string autoSelectKoHex(const std::string &ver)
{
    printf("[*] 检测内核版本: %s\n", ver.c_str());
    if (ver.find("6.12.38") != std::string::npos) {
        printf("[+] 自动匹配 A16‑6.12.38\n");
        return A16_6_12_38;
    }
    if (ver.find("6.12.58") != std::string::npos) {
        printf("[+] 自动匹配 A16‑6.12.58\n");
        return A16_6_12_58;
    }
    if (ver.find("6.12.69") != std::string::npos) {
        printf("[+] 自动匹配 A16‑6.12.69\n");
        return A16_6_12_69;
    }
    if (ver.find("6.12") != std::string::npos) {
        printf("[-] 6.12小版本不匹配，自动模式失败\n");
        return "";
    }
    if (ver.find("6.6") != std::string::npos) {
        printf("[+] 自动匹配 A15‑6.6\n");
        return A15_6_6;
    }
    if (ver.find("6.1") != std::string::npos) {
        printf("[+] 自动匹配 A14‑6.1\n");
        return A14_6_1;
    }
    if (ver.find("5.15") != std::string::npos) {
        printf("[+] 自动匹配 A14‑5.15\n");
        return A14_5_15;
    }
    if (ver.find("5.10") != std::string::npos) {
        printf("[+] 自动匹配 A13‑5.10\n");
        return A13_5_10;
    }
    printf("[-] 未识别内核版本，自动模式失败\n");
    return "";
}

int doFlashKo(const std::string &koHex)
{
    if(koHex.empty()){
        printf("[-] ko hex为空\n");
        return -1;
    }
    std::string randDir = getRandomDataDir();
    std::string tmpKoPath = randDir + "/" + generateRandomStr(40);
   // printf("[*] 临时文件路径：%s\n", tmpKoPath.c_str());

    if(!hexStringToFile(koHex, tmpKoPath))
    {
        fprintf(stderr,"[-] 刷入失败\n");
        return -2;
    }

    std::string cmd = "insmod " + tmpKoPath + " >/dev/null 2>&1";
    int ret = system(cmd.c_str());
    int exitCode = WEXITSTATUS(ret);
    printf("[*] insmod返回值：%d\n", exitCode);

    remove(tmpKoPath.c_str());
  //  printf("[*] 临时文件已删除\n");
    return exitCode;
}
